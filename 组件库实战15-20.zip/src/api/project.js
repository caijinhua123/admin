import request from '@/utils/request'
import { getToken} from '@/utils/auth'

export function getproject(){//获取所有项目
    return request({
        url: '/api/project',
        method: 'get',
      })
}

export function putproject(id,data){//修改项目
    let newdata ={...data}
    newdata.description = newdata.description.split(',')
    return request({
        url: `/api/project/${id}`,
        method: 'put',
        headers:{
            'Authorization':'Bearer '+getToken()
        },
        newdata
    })
}


export function addproject(data){//新增项目
    return request({
        url: '/api/project',
        method: 'post',
        headers:{
            'Authorization':'Bearer '+getToken()
        },
        data
      })
}

export function deleteproject(id){//根据id删除项目
    return request({
        url: `/api/project/${id}`,
        method: 'delete',
        headers:{
            'Authorization':'Bearer '+getToken()
        },
      })
}
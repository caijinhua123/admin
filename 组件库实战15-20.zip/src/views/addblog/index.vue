<template>
  <Addblog />
</template>

<script>
import Addblog from '@/components/addblog' 
export default {
  components:{
    Addblog
  }
}
</script>

<style>

</style>
<template>
  <Addproject />
</template>

<script>
import Addproject from '@/components/addproject'
export default {
    components:{
        Addproject
    }
}
</script>

<style>

</style>
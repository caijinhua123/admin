<template>
  <div>关于我</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
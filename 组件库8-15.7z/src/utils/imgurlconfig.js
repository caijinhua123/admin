
export default function ImgUrlconfig(){
    return 'http://47.111.172.167:7001';
} 